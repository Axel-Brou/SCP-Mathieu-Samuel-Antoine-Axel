/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: V1.c
 *
 * Code generated for Simulink model 'V1'.
 *
 * Model version                  : 1.1
 * Simulink Coder version         : 9.4 (R2020b) 29-Jul-2020
 * C/C++ source code generated on : Mon Jun 13 10:37:34 2022
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR (8-bit)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "V1.h"
#include "V1_private.h"

/* Block signals (default storage) */
B_V1_T V1_B;

/* Continuous states */
X_V1_T V1_X;

/* External inputs (root inport signals with default storage) */
ExtU_V1_T V1_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_V1_T V1_Y;

/* Real-time model */
static RT_MODEL_V1_T V1_M_;
RT_MODEL_V1_T *const V1_M = &V1_M_;

/*
 * This function updates continuous states using the ODE1 fixed-step
 * solver algorithm
 */
static void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si )
{
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE1_IntgData *id = (ODE1_IntgData *)rtsiGetSolverData(si);
  real_T *f0 = id->f[0];
  int_T i;
  int_T nXc = 2;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);
  rtsiSetdX(si, f0);
  V1_derivatives();
  rtsiSetT(si, tnew);
  for (i = 0; i < nXc; ++i) {
    x[i] += h * f0[i];
  }

  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model step function */
void V1_step(void)
{
  real_T rtb_Sum1;
  real_T rtb_Sum2;
  real_T rtb_Sum2_tmp;
  real_T rtb_Sum2_tmp_0;
  real_T rtb_gainenmms;
  if (rtmIsMajorTimeStep(V1_M)) {
    /* set solver stop time */
    rtsiSetSolverStopTime(&V1_M->solverInfo,((V1_M->Timing.clockTick0+1)*
      V1_M->Timing.stepSize0));
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep(V1_M)) {
    V1_M->Timing.t[0] = rtsiGetT(&V1_M->solverInfo);
  }

  /* Sum: '<S3>/Sum2' incorporates:
   *  Gain: '<S3>/Gain2'
   *  Gain: '<S3>/Gain3'
   *  Inport: '<Root>/VG'
   *  Integrator: '<S3>/Integrator1'
   */
  rtb_gainenmms = (0.0 - V1_P.KI * V1_X.Integrator1_CSTATE) - V1_P.Kx * V1_U.VG;

  /* Saturate: '<S3>/Saturation2' */
  if (rtb_gainenmms > V1_P.Saturation2_UpperSat) {
    /* Saturate: '<S3>/Saturation2' */
    V1_Y.Ug = V1_P.Saturation2_UpperSat;
  } else if (rtb_gainenmms < V1_P.Saturation2_LowerSat) {
    /* Saturate: '<S3>/Saturation2' */
    V1_Y.Ug = V1_P.Saturation2_LowerSat;
  } else {
    /* Saturate: '<S3>/Saturation2' */
    V1_Y.Ug = rtb_gainenmms;
  }

  /* End of Saturate: '<S3>/Saturation2' */

  /* Sum: '<S3>/Sum1' */
  rtb_Sum1 = V1_Y.Ug - rtb_gainenmms;

  /* Gain: '<S4>/gain en mm//s' incorporates:
   *  Inport: '<Root>/x'
   *  Inport: '<Root>/x+'
   *  Sum: '<S4>/Add'
   */
  rtb_gainenmms = (V1_U.x_d - V1_U.x) * V1_P.gainenmms_Gain;

  /* Saturate: '<S2>/Saturation2' incorporates:
   *  Inport: '<Root>/y'
   *  Inport: '<Root>/y+'
   *  Sum: '<S5>/Add'
   */
  V1_Y.Ud = V1_U.y - V1_U.y_g;

  /* Trigonometry: '<S6>/Sin' incorporates:
   *  Inport: '<Root>/Theta'
   *  Trigonometry: '<S6>/Sin1'
   */
  rtb_Sum2_tmp = sin(V1_U.Theta);

  /* Trigonometry: '<S6>/Cos' incorporates:
   *  Inport: '<Root>/Theta'
   *  Trigonometry: '<S6>/Cos1'
   */
  rtb_Sum2_tmp_0 = cos(V1_U.Theta);

  /* Sum: '<S6>/Add' incorporates:
   *  Product: '<S6>/Divide'
   *  Product: '<S6>/Divide1'
   *  Trigonometry: '<S6>/Cos'
   *  Trigonometry: '<S6>/Sin'
   */
  rtb_Sum2 = rtb_Sum2_tmp_0 * rtb_gainenmms + rtb_Sum2_tmp * V1_Y.Ud;

  /* Saturate: '<S1>/Saturation2' */
  if (rtb_Sum2 > V1_P.Saturation2_UpperSat_j) {
    rtb_Sum2 = V1_P.Saturation2_UpperSat_j;
  } else {
    if (rtb_Sum2 < V1_P.Saturation2_LowerSat_l) {
      rtb_Sum2 = V1_P.Saturation2_LowerSat_l;
    }
  }

  /* End of Saturate: '<S1>/Saturation2' */

  /* Saturate: '<S2>/Saturation2' incorporates:
   *  Constant: '<S6>/Constant1'
   *  Gain: '<S6>/Gain1'
   *  Gain: '<S7>/Gain'
   *  Product: '<S6>/Divide2'
   *  Product: '<S6>/Divide3'
   *  Sum: '<S6>/Add1'
   */
  V1_Y.Ud = (V1_P.Gain1_Gain * rtb_Sum2_tmp * rtb_gainenmms / V1_P.L +
             rtb_Sum2_tmp_0 * V1_Y.Ud / V1_P.L) * V1_P.p;

  /* Sum: '<S3>/Sum' incorporates:
   *  Gain: '<S3>/Gain'
   *  Inport: '<Root>/VG'
   *  Sum: '<S7>/Add'
   */
  V1_B.Sum = (V1_P.Gain_Gain * rtb_Sum1 + (rtb_Sum2 - V1_Y.Ud)) - V1_U.VG;

  /* Sum: '<S7>/Add1' */
  rtb_gainenmms = rtb_Sum2 + V1_Y.Ud;

  /* Sum: '<S2>/Sum2' incorporates:
   *  Gain: '<S2>/Gain2'
   *  Gain: '<S2>/Gain3'
   *  Inport: '<Root>/VD'
   *  Integrator: '<S2>/Integrator1'
   */
  rtb_Sum2 = (0.0 - V1_P.KI * V1_X.Integrator1_CSTATE_d) - V1_P.Kx * V1_U.VD;

  /* Saturate: '<S2>/Saturation2' */
  if (rtb_Sum2 > V1_P.Saturation2_UpperSat_b) {
    /* Saturate: '<S2>/Saturation2' */
    V1_Y.Ud = V1_P.Saturation2_UpperSat_b;
  } else if (rtb_Sum2 < V1_P.Saturation2_LowerSat_e) {
    /* Saturate: '<S2>/Saturation2' */
    V1_Y.Ud = V1_P.Saturation2_LowerSat_e;
  } else {
    /* Saturate: '<S2>/Saturation2' */
    V1_Y.Ud = rtb_Sum2;
  }

  /* End of Saturate: '<S2>/Saturation2' */

  /* Sum: '<S2>/Sum' incorporates:
   *  Gain: '<S2>/Gain'
   *  Inport: '<Root>/VD'
   *  Sum: '<S2>/Sum1'
   */
  V1_B.Sum_e = ((V1_Y.Ud - rtb_Sum2) * V1_P.Gain_Gain_o + rtb_gainenmms) -
    V1_U.VD;
  if (rtmIsMajorTimeStep(V1_M)) {
    rt_ertODEUpdateContinuousStates(&V1_M->solverInfo);

    /* Update absolute time for base rate */
    /* The "clockTick0" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick0"
     * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
     * overflow during the application lifespan selected.
     */
    ++V1_M->Timing.clockTick0;
    V1_M->Timing.t[0] = rtsiGetSolverStopTime(&V1_M->solverInfo);

    {
      /* Update absolute timer for sample time: [0.005s, 0.0s] */
      /* The "clockTick1" counts the number of times the code of this task has
       * been executed. The resolution of this integer timer is 0.005, which is the step size
       * of the task. Size of "clockTick1" ensures timer will not overflow during the
       * application lifespan selected.
       */
      V1_M->Timing.clockTick1++;
    }
  }                                    /* end MajorTimeStep */
}

/* Derivatives for root system: '<Root>' */
void V1_derivatives(void)
{
  XDot_V1_T *_rtXdot;
  _rtXdot = ((XDot_V1_T *) V1_M->derivs);

  /* Derivatives for Integrator: '<S3>/Integrator1' */
  _rtXdot->Integrator1_CSTATE = V1_B.Sum;

  /* Derivatives for Integrator: '<S2>/Integrator1' */
  _rtXdot->Integrator1_CSTATE_d = V1_B.Sum_e;
}

/* Model initialize function */
void V1_initialize(void)
{
  /* Registration code */
  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&V1_M->solverInfo, &V1_M->Timing.simTimeStep);
    rtsiSetTPtr(&V1_M->solverInfo, &rtmGetTPtr(V1_M));
    rtsiSetStepSizePtr(&V1_M->solverInfo, &V1_M->Timing.stepSize0);
    rtsiSetdXPtr(&V1_M->solverInfo, &V1_M->derivs);
    rtsiSetContStatesPtr(&V1_M->solverInfo, (real_T **) &V1_M->contStates);
    rtsiSetNumContStatesPtr(&V1_M->solverInfo, &V1_M->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&V1_M->solverInfo,
      &V1_M->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&V1_M->solverInfo,
      &V1_M->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&V1_M->solverInfo,
      &V1_M->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&V1_M->solverInfo, (&rtmGetErrorStatus(V1_M)));
    rtsiSetRTModelPtr(&V1_M->solverInfo, V1_M);
  }

  rtsiSetSimTimeStep(&V1_M->solverInfo, MAJOR_TIME_STEP);
  V1_M->intgData.f[0] = V1_M->odeF[0];
  V1_M->contStates = ((X_V1_T *) &V1_X);
  rtsiSetSolverData(&V1_M->solverInfo, (void *)&V1_M->intgData);
  rtsiSetSolverName(&V1_M->solverInfo,"ode1");
  rtmSetTPtr(V1_M, &V1_M->Timing.tArray[0]);
  V1_M->Timing.stepSize0 = 0.005;

  /* InitializeConditions for Integrator: '<S3>/Integrator1' */
  V1_X.Integrator1_CSTATE = V1_P.Integrator1_IC;

  /* InitializeConditions for Integrator: '<S2>/Integrator1' */
  V1_X.Integrator1_CSTATE_d = V1_P.Integrator1_IC_j;
}

/* Model terminate function */
void V1_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
