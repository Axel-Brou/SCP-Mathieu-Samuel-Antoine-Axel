/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: V1_data.c
 *
 * Code generated for Simulink model 'V1'.
 *
 * Model version                  : 1.1
 * Simulink Coder version         : 9.4 (R2020b) 29-Jul-2020
 * C/C++ source code generated on : Mon Jun 13 10:37:34 2022
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR (8-bit)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "V1.h"
#include "V1_private.h"

/* Block parameters (default storage) */
P_V1_T V1_P = {
  /* Variable: KI
   * Referenced by:
   *   '<S2>/Gain2'
   *   '<S3>/Gain2'
   */
  -3.1999999999996209,

  /* Variable: Kx
   * Referenced by:
   *   '<S2>/Gain3'
   *   '<S3>/Gain3'
   */
  0.05199999999999573,

  /* Variable: L
   * Referenced by: '<S6>/Constant1'
   */
  185.0,

  /* Variable: p
   * Referenced by: '<S7>/Gain'
   */
  100.0,

  /* Expression: 0
   * Referenced by: '<S3>/Integrator1'
   */
  0.0,

  /* Expression: 9
   * Referenced by: '<S3>/Saturation2'
   */
  9.0,

  /* Expression: -9
   * Referenced by: '<S3>/Saturation2'
   */
  -9.0,

  /* Expression: 55
   * Referenced by: '<S3>/Gain'
   */
  55.0,

  /* Expression: 1
   * Referenced by: '<S4>/gain en mm//s'
   */
  1.0,

  /* Expression: 360
   * Referenced by: '<S1>/Saturation2'
   */
  360.0,

  /* Expression: -360
   * Referenced by: '<S1>/Saturation2'
   */
  -360.0,

  /* Expression: -1
   * Referenced by: '<S6>/Gain1'
   */
  -1.0,

  /* Expression: 0
   * Referenced by: '<S2>/Integrator1'
   */
  0.0,

  /* Expression: 9
   * Referenced by: '<S2>/Saturation2'
   */
  9.0,

  /* Expression: -9
   * Referenced by: '<S2>/Saturation2'
   */
  -9.0,

  /* Expression: 55
   * Referenced by: '<S2>/Gain'
   */
  55.0
};

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
