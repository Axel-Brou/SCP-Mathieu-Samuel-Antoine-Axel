/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: V1.h
 *
 * Code generated for Simulink model 'V1'.
 *
 * Model version                  : 1.1
 * Simulink Coder version         : 9.4 (R2020b) 29-Jul-2020
 * C/C++ source code generated on : Mon Jun 13 10:37:34 2022
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR (8-bit)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_V1_h_
#define RTW_HEADER_V1_h_
#include <math.h>
#ifndef V1_COMMON_INCLUDES_
#define V1_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#endif                                 /* V1_COMMON_INCLUDES_ */

#include "V1_types.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
#define rtmGetStopRequested(rtm)       ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
#define rtmSetStopRequested(rtm, val)  ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
#define rtmGetStopRequestedPtr(rtm)    (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
#define rtmGetT(rtm)                   (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTPtr
#define rtmGetTPtr(rtm)                ((rtm)->Timing.t)
#endif

/* Block signals (default storage) */
typedef struct {
  real_T Sum;                          /* '<S3>/Sum' */
  real_T Sum_e;                        /* '<S2>/Sum' */
} B_V1_T;

/* Continuous states (default storage) */
typedef struct {
  real_T Integrator1_CSTATE;           /* '<S3>/Integrator1' */
  real_T Integrator1_CSTATE_d;         /* '<S2>/Integrator1' */
} X_V1_T;

/* State derivatives (default storage) */
typedef struct {
  real_T Integrator1_CSTATE;           /* '<S3>/Integrator1' */
  real_T Integrator1_CSTATE_d;         /* '<S2>/Integrator1' */
} XDot_V1_T;

/* State disabled  */
typedef struct {
  boolean_T Integrator1_CSTATE;        /* '<S3>/Integrator1' */
  boolean_T Integrator1_CSTATE_d;      /* '<S2>/Integrator1' */
} XDis_V1_T;

#ifndef ODE1_INTG
#define ODE1_INTG

/* ODE1 Integration Data */
typedef struct {
  real_T *f[1];                        /* derivatives */
} ODE1_IntgData;

#endif

/* External inputs (root inport signals with default storage) */
typedef struct {
  real_T x;                            /* '<Root>/x' */
  real_T VG;                           /* '<Root>/VG' */
  real_T x_d;                          /* '<Root>/x+' */
  real_T y;                            /* '<Root>/y+' */
  real_T VD;                           /* '<Root>/VD' */
  real_T Theta;                        /* '<Root>/Theta' */
  real_T y_g;                          /* '<Root>/y' */
} ExtU_V1_T;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  real_T Ug;                           /* '<Root>/Ug' */
  real_T Ud;                           /* '<Root>/Ud' */
} ExtY_V1_T;

/* Parameters (default storage) */
struct P_V1_T_ {
  real_T KI;                           /* Variable: KI
                                        * Referenced by:
                                        *   '<S2>/Gain2'
                                        *   '<S3>/Gain2'
                                        */
  real_T Kx;                           /* Variable: Kx
                                        * Referenced by:
                                        *   '<S2>/Gain3'
                                        *   '<S3>/Gain3'
                                        */
  real_T L;                            /* Variable: L
                                        * Referenced by: '<S6>/Constant1'
                                        */
  real_T p;                            /* Variable: p
                                        * Referenced by: '<S7>/Gain'
                                        */
  real_T Integrator1_IC;               /* Expression: 0
                                        * Referenced by: '<S3>/Integrator1'
                                        */
  real_T Saturation2_UpperSat;         /* Expression: 9
                                        * Referenced by: '<S3>/Saturation2'
                                        */
  real_T Saturation2_LowerSat;         /* Expression: -9
                                        * Referenced by: '<S3>/Saturation2'
                                        */
  real_T Gain_Gain;                    /* Expression: 55
                                        * Referenced by: '<S3>/Gain'
                                        */
  real_T gainenmms_Gain;               /* Expression: 1
                                        * Referenced by: '<S4>/gain en mm//s'
                                        */
  real_T Saturation2_UpperSat_j;       /* Expression: 360
                                        * Referenced by: '<S1>/Saturation2'
                                        */
  real_T Saturation2_LowerSat_l;       /* Expression: -360
                                        * Referenced by: '<S1>/Saturation2'
                                        */
  real_T Gain1_Gain;                   /* Expression: -1
                                        * Referenced by: '<S6>/Gain1'
                                        */
  real_T Integrator1_IC_j;             /* Expression: 0
                                        * Referenced by: '<S2>/Integrator1'
                                        */
  real_T Saturation2_UpperSat_b;       /* Expression: 9
                                        * Referenced by: '<S2>/Saturation2'
                                        */
  real_T Saturation2_LowerSat_e;       /* Expression: -9
                                        * Referenced by: '<S2>/Saturation2'
                                        */
  real_T Gain_Gain_o;                  /* Expression: 55
                                        * Referenced by: '<S2>/Gain'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_V1_T {
  const char_T *errorStatus;
  RTWSolverInfo solverInfo;
  X_V1_T *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  boolean_T *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;
  real_T odeF[1][2];
  ODE1_IntgData intgData;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numSampTimes;
  } Sizes;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    time_T stepSize0;
    uint32_T clockTick1;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

/* Block parameters (default storage) */
extern P_V1_T V1_P;

/* Block signals (default storage) */
extern B_V1_T V1_B;

/* Continuous states (default storage) */
extern X_V1_T V1_X;

/* External inputs (root inport signals with default storage) */
extern ExtU_V1_T V1_U;

/* External outputs (root outports fed by signals with default storage) */
extern ExtY_V1_T V1_Y;

/* Model entry point functions */
extern void V1_initialize(void);
extern void V1_step(void);
extern void V1_terminate(void);

/* Real-time Model object */
extern RT_MODEL_V1_T *const V1_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Note that this particular code originates from a subsystem build,
 * and has its own system numbers different from the parent model.
 * Refer to the system hierarchy for this subsystem below, and use the
 * MATLAB hilite_system command to trace the generated code back
 * to the parent model.  For example,
 *
 * hilite_system('SCH_V1/V1')    - opens subsystem SCH_V1/V1
 * hilite_system('SCH_V1/V1/Kp') - opens and selects block Kp
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'SCH_V1'
 * '<S1>'   : 'SCH_V1/V1'
 * '<S2>'   : 'SCH_V1/V1/Asservissement VD'
 * '<S3>'   : 'SCH_V1/V1/Asservissement VG'
 * '<S4>'   : 'SCH_V1/V1/Controleur x'
 * '<S5>'   : 'SCH_V1/V1/Controleur y'
 * '<S6>'   : 'SCH_V1/V1/MInv'
 * '<S7>'   : 'SCH_V1/V1/Subsystem3'
 */
#endif                                 /* RTW_HEADER_V1_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
